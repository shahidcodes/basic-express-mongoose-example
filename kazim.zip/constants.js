module.exports = {
  jwtSecret: "abcdee",
};
